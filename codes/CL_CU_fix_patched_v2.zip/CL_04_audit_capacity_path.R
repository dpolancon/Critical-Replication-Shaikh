# ============================================================
# AUDIT — CAPACITY PATH RECOVERY AND UTILIZATION IDENTITY
# Runs after CL_03_results_package_mu_theta_wsh.R outputs are available
# ============================================================

suppressPackageStartupMessages({
  library(here)
  library(readr)
  library(dplyr)
  library(tibble)
})

path_stage2_root <- here::here("output", "chile_2Smu_S2_tdols")
out_csv <- file.path(path_stage2_root, "csv")
out_txt <- file.path(path_stage2_root, "txt")

dir.create(out_txt, recursive = TRUE, showWarnings = FALSE)

path_threshold <- file.path(out_csv, "results_ts_splice_1932_2010.csv")
path_baseline  <- file.path(out_csv, "results_ts_baseline_splice_1932_2010.csv")

need_files <- c(path_threshold, path_baseline)
missing_files <- need_files[!file.exists(need_files)]
if (length(missing_files) > 0) {
  stop("Missing required results datasets:\n", paste(missing_files, collapse = "\n"), call. = FALSE)
}

write_txt <- function(lines, path) {
  writeLines(as.character(lines), con = path, useBytes = TRUE)
}

audit_capacity_path <- function(df, label, pinch_year = 1980, tol = 1e-10) {
  df <- df %>% arrange(year)
  idx0 <- which(df$year == pinch_year)
  if (length(idx0) != 1L) {
    stop(label, ": pinch year not found uniquely.", call. = FALSE)
  }
  
  pinch_u <- df$u[idx0]
  pinch_gap <- df$log_u_gap[idx0]
  max_identity_err <- max(abs(df$log_u_gap - (df$y - df$log_y_p)), na.rm = TRUE)
  
  forward_resid <- if (idx0 < nrow(df)) {
    max(abs((df$log_y_p[(idx0 + 1):nrow(df)] - df$log_y_p[idx0:(nrow(df) - 1)]) -
              (df$theta_active[(idx0 + 1):nrow(df)] * df$dlog_k_nr[(idx0 + 1):nrow(df)])), na.rm = TRUE)
  } else {
    0
  }
  
  backward_resid <- if (idx0 > 1) {
    max(abs((df$log_y_p[1:(idx0 - 1)] - df$log_y_p[2:idx0]) +
              (df$theta_active[2:idx0] * df$dlog_k_nr[2:idx0])), na.rm = TRUE)
  } else {
    0
  }
  
  tibble(
    package = label,
    n_obs = nrow(df),
    start_year = min(df$year, na.rm = TRUE),
    end_year = max(df$year, na.rm = TRUE),
    pinch_year = pinch_year,
    pinch_u = pinch_u,
    pinch_log_u_gap = pinch_gap,
    mean_u = mean(df$u, na.rm = TRUE),
    sd_u = sd(df$u, na.rm = TRUE),
    min_u = min(df$u, na.rm = TRUE),
    max_u = max(df$u, na.rm = TRUE),
    max_identity_err = max_identity_err,
    max_forward_recursion_err = forward_resid,
    max_backward_recursion_err = backward_resid,
    pinch_u_ok = abs(pinch_u - 1) <= tol,
    pinch_gap_ok = abs(pinch_gap) <= tol,
    identity_ok = max_identity_err <= tol,
    forward_ok = forward_resid <= tol,
    backward_ok = backward_resid <= tol
  )
}

threshold_df <- read_csv(path_threshold, show_col_types = FALSE)
baseline_df  <- read_csv(path_baseline, show_col_types = FALSE)

audit_tbl <- bind_rows(
  audit_capacity_path(threshold_df, "threshold_splice"),
  audit_capacity_path(baseline_df,  "baseline_splice")
)

write_csv(audit_tbl, file.path(out_csv, "results_capacity_path_audit.csv"))

summary_lines <- c(
  "Capacity-path audit completed.",
  "",
  "Checks:",
  " - pinch-year normalization u_1980 = 1",
  " - log utilization identity: log_u_gap = y - log_y_p",
  " - forward recursion for productive capacity in logs",
  " - backward recursion for productive capacity in logs",
  "",
  "Outputs:",
  " - csv/results_capacity_path_audit.csv",
  ""
)

for (i in seq_len(nrow(audit_tbl))) {
  row <- audit_tbl[i, ]
  summary_lines <- c(
    summary_lines,
    paste0("Package: ", row$package),
    paste0(" - pinch_u = ", format(row$pinch_u, digits = 16)),
    paste0(" - pinch_log_u_gap = ", format(row$pinch_log_u_gap, digits = 16)),
    paste0(" - max identity error = ", format(row$max_identity_err, digits = 16)),
    paste0(" - max forward recursion error = ", format(row$max_forward_recursion_err, digits = 16)),
    paste0(" - max backward recursion error = ", format(row$max_backward_recursion_err, digits = 16)),
    paste0(" - status = ", ifelse(all(unlist(row[c("pinch_u_ok", "pinch_gap_ok", "identity_ok", "forward_ok", "backward_ok")])), "PASS", "CHECK")),
    ""
  )
}

write_txt(summary_lines, file.path(out_txt, "results_capacity_path_audit_summary.txt"))
cat(paste(summary_lines, collapse = "\n"), "\n")
